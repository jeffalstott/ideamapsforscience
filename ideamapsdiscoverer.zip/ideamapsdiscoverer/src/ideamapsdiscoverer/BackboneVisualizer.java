/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ideamapsdiscoverer;

import javax.swing.JFrame;

import javax.swing.JOptionPane;
import prefuse.Constants;
import prefuse.Display;
import prefuse.Visualization;
import prefuse.action.ActionList;
import prefuse.action.RepaintAction;
import prefuse.action.assignment.ColorAction;
import prefuse.action.assignment.DataColorAction;
import prefuse.action.layout.graph.ForceDirectedLayout;
import prefuse.activity.Activity;
import prefuse.controls.FocusControl;
import prefuse.controls.DragControl;
import prefuse.controls.PanControl;
import prefuse.controls.ZoomControl;
import prefuse.controls.NeighborHighlightControl;
import prefuse.data.Graph;
import prefuse.data.io.DataIOException;
import prefuse.data.io.GraphMLReader;
import prefuse.render.DefaultRendererFactory;
import prefuse.render.LabelRenderer;
import prefuse.util.ColorLib;
import prefuse.visual.VisualItem;
import prefuse.util.force.ForceSimulator;

public class BackboneVisualizer {

    public static void run(String fieldName, String field, int year, boolean full) {
        // -- 1. load the data ------------------------------------------------

        // load the socialnet.xml file. it is assumed that the file can be
        // found at the root of the java classpath

        MatlabToPrefuseXml mtpx = new MatlabToPrefuseXml(field, year);
        if(full)
            if(!mtpx.writeXml())
                return;

        if(!full)
            if(!mtpx.writeModifiedXml())
                return;
        
        Graph graph = null;
        try {
            System.out.println(mtpx.getPathToXmlFile());
            graph = new GraphMLReader().readGraph(mtpx.getPathToXmlFile());
        } catch ( Exception e ) {
            e.printStackTrace();
            System.err.println("Error loading graph. Exiting...");
            System.exit(1);
        }


        // -- 2. the visualization --------------------------------------------

        // add the graph to the visualization as the data group "graph"
        // nodes and edges are accessible as "graph.nodes" and "graph.edges"
        Visualization vis = new Visualization();
        vis.add("graph", graph);
        vis.setInteractive("graph.edges", null, false);

        // -- 3. the renderers and renderer factory ---------------------------

        // draw the "name" label for NodeItems
        LabelRenderer r = new LabelRenderer("term");
        r.setRoundedCorner(8, 8); // round the corners

        // create a new default renderer factory
        // return our name label renderer as the default for all non-EdgeItems
        // includes straight line edges for EdgeItems by default
        vis.setRendererFactory(new DefaultRendererFactory(r));


        // -- 4. the processing actions ---------------------------------------

        // create our nominal color palette
        int[] palette = new int[] {
            ColorLib.rgb(255,255,78),
            ColorLib.rgb(191,79,153),
            ColorLib.rgb(78,255,77),
            ColorLib.rgb(254,96,78),
            ColorLib.rgb(78,184,184),
            ColorLib.rgb(78,78,255),
            ColorLib.rgb(204,204,204)
        };
        
        // map nominal data values to colors using our provided palette
        DataColorAction fill = new DataColorAction("graph.nodes", "module",
                Constants.NUMERICAL, VisualItem.FILLCOLOR, palette);
        fill.add("_fixed", ColorLib.rgb(0,153,0));
        fill.add("_highlight", ColorLib.rgb(255,0,0));
        // color for node text
        ColorAction text = new ColorAction("graph.nodes",
                VisualItem.TEXTCOLOR, ColorLib.gray(0));
        
//        // color for edges
//        ColorAction edges = new ColorAction("graph.edges",
//                VisualItem.STROKECOLOR, ColorLib.gray(200));

        // create an action list containing all color assignments
        ActionList color = new ActionList();
        color.add(text);
        color.add(new ColorAction("graph.edges", VisualItem.FILLCOLOR, ColorLib.gray(200)));
        color.add(new ColorAction("graph.edges", VisualItem.STROKECOLOR, ColorLib.gray(200)));


        // create an action list with an animated layout
        WeightedForceDirectedLayout fdl = new WeightedForceDirectedLayout("graph");
        ForceSimulator fsim = fdl.getForceSimulator();
        fsim.getForces()[0].setParameter(0, -1.2f);
        
        ActionList layout = new ActionList(Activity.INFINITY);
        layout.add(fdl);
        layout.add(fill);
        layout.add(new RepaintAction());

        // add the actions to the visualization
        vis.putAction("color", color);
        vis.putAction("layout", layout);
        vis.runAfter("color", "layout");


        // -- 5. the display and interactive controls -------------------------

        Display d = new Display(vis);
        d.setSize(720, 500); // set display size
//        d.addControlListener(new FocusControl(1));
        // drag individual items around
        d.addControlListener(new DragControl());
        // pan with left-click drag on background
        d.addControlListener(new PanControl());
        // zoom with right-click drag
        d.addControlListener(new ZoomControl());
        
        d.addControlListener(new NeighborHighlightControl());

        // -- 6. launch the visualization -------------------------------------

        // create a new window to hold the visualization
        JFrame frame = new JFrame("Network backbone for " + fieldName + " in " + Integer.toString(year));
        // ensure application exits when window is closed
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.add(d);
        frame.pack();           // layout components in window
        frame.setVisible(true); // show the window

        // assign the colors
        vis.run("color");
        // start up the animated layout
        vis.run("layout");
    }


    public static void run(String fieldName, String field, int year, int termId, String target) {
        // -- 1. load the data ------------------------------------------------

        // load the socialnet.xml file. it is assumed that the file can be
        // found at the root of the java classpath

        MatlabToPrefuseXml mtpx = new MatlabToPrefuseXml(field, year);
        
        if(!mtpx.writeModifiedXmlTargeted(termId))
            return;
        
        Graph graph = null;
        try {
            System.out.println(mtpx.getPathToXmlFile());
            graph = new GraphMLReader().readGraph(mtpx.getPathToXmlFile());
        } catch ( Exception e ) {
            e.printStackTrace();
            System.err.println("Error loading graph. Exiting...");
            System.exit(1);
        }


        // -- 2. the visualization --------------------------------------------

        // add the graph to the visualization as the data group "graph"
        // nodes and edges are accessible as "graph.nodes" and "graph.edges"
        Visualization vis = new Visualization();
        vis.add("graph", graph);
        vis.setInteractive("graph.edges", null, false);

        // -- 3. the renderers and renderer factory ---------------------------

        // draw the "name" label for NodeItems
        LabelRenderer r = new LabelRenderer("term");
        r.setRoundedCorner(8, 8); // round the corners

        // create a new default renderer factory
        // return our name label renderer as the default for all non-EdgeItems
        // includes straight line edges for EdgeItems by default
        vis.setRendererFactory(new DefaultRendererFactory(r));


        // -- 4. the processing actions ---------------------------------------

        // create our nominal color palette
        int[] palette = new int[] {
            ColorLib.rgb(255,255,78),
            ColorLib.rgb(191,79,153),
            ColorLib.rgb(78,255,77),
            ColorLib.rgb(254,96,78),
            ColorLib.rgb(78,184,184),
            ColorLib.rgb(78,78,255),
            ColorLib.rgb(204,204,204)
        };

        // map nominal data values to colors using our provided palette
        DataColorAction fill = new DataColorAction("graph.nodes", "module",
                Constants.NUMERICAL, VisualItem.FILLCOLOR, palette);
        fill.add("_fixed", ColorLib.rgb(0,153,0));
        fill.add("_highlight", ColorLib.rgb(255,0,0));
        // color for node text
        ColorAction text = new ColorAction("graph.nodes",
                VisualItem.TEXTCOLOR, ColorLib.gray(0));

//        // color for edges
//        ColorAction edges = new ColorAction("graph.edges",
//                VisualItem.STROKECOLOR, ColorLib.gray(200));

        // create an action list containing all color assignments
        ActionList color = new ActionList();
        color.add(text);
        color.add(new ColorAction("graph.edges", VisualItem.FILLCOLOR, ColorLib.gray(200)));
        color.add(new ColorAction("graph.edges", VisualItem.STROKECOLOR, ColorLib.gray(200)));


        // create an action list with an animated layout
        WeightedForceDirectedLayout fdl = new WeightedForceDirectedLayout("graph");
        ForceSimulator fsim = fdl.getForceSimulator();
        fsim.getForces()[0].setParameter(0, -1.2f);

        ActionList layout = new ActionList(Activity.INFINITY);
        layout.add(fdl);
        layout.add(fill);
        layout.add(new RepaintAction());

        // add the actions to the visualization
        vis.putAction("color", color);
        vis.putAction("layout", layout);
        vis.runAfter("color", "layout");


        // -- 5. the display and interactive controls -------------------------

        Display d = new Display(vis);
        d.setSize(720, 500); // set display size
//        d.addControlListener(new FocusControl(1));
        // drag individual items around
        d.addControlListener(new DragControl());
        // pan with left-click drag on background
        d.addControlListener(new PanControl());
        // zoom with right-click drag
        d.addControlListener(new ZoomControl());

        d.addControlListener(new NeighborHighlightControl());

        // -- 6. launch the visualization -------------------------------------

        // create a new window to hold the visualization
        JFrame frame = new JFrame("Network backbone for '" + target + "' in " + fieldName + " in " + Integer.toString(year));
        // ensure application exits when window is closed
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.add(d);
        frame.pack();           // layout components in window
        frame.setVisible(true); // show the window

        // assign the colors
        vis.run("color");
        // start up the animated layout
        vis.run("layout");
    }

}
