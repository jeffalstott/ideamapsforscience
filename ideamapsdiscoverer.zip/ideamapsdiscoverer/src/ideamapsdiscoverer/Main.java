/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ideamapsdiscoverer;

import javax.swing.JOptionPane;

/**
 *
 * @author Hoang Diep
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        int res = JOptionPane.showConfirmDialog(null, "To explore network, choose YES. To visualize network, choose No");
////        System.out.println(Integer.toString(res));
//        if(res == 0)
//            FormMain.main(args);
//        else if(res == 1)
//            BackboneVisualizer.main(args);
        FormMain.main(args);
    }

}
