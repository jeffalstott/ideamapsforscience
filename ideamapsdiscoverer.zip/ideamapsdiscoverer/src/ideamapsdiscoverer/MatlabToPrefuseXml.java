/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ideamapsdiscoverer;

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 *
 * @author Diep
 */
public class MatlabToPrefuseXml {

    class Node {

        String term;
        int module;
    }

    class Edge {

        String source;
        String target;
        float distance;
    }
    int MODULE_INDEX = 3;
    String pathToNodeInfo = "../data/Nodes/";
    String pathToBackboneInfo = "../data/NetworkBackbones/";
    String prefuseFName;
    String field;
    int year;
    ArrayList<Node> nodes = new ArrayList();
    ArrayList<Edge> edges = new ArrayList();

    public MatlabToPrefuseXml(String _field, int _year) {
        field = _field;
        year = _year;
    }

    public MatlabToPrefuseXml(String _field, int _year, String ptni, String ptbi) {
        field = _field;
        year = _year;
        pathToNodeInfo = ptni;
        pathToBackboneInfo = ptbi;
    }
        
    public String getPathToXmlFile() {
        return prefuseFName;
    }

    public boolean writeXml() {
        // read (term, module)s
        String termFileName = pathToBackboneInfo + field + "." + Integer.toString(year) + ".terms";
        String moduleFileName = pathToNodeInfo + "d." + field + "." + Integer.toString(year) + ".txt";
//        JOptionPane.showMessageDialog(null, termFileName);
//        JOptionPane.showMessageDialog(null, moduleFileName);
        try {
            BufferedReader inmodule = new BufferedReader(new FileReader(moduleFileName));
            String str;

            while ((str = inmodule.readLine()) != null) {
                String[] metrics = str.split(";");
                Node anode = new Node();
                anode.module = Integer.parseInt(metrics[MODULE_INDEX]);
                nodes.add(anode);
            }
            inmodule.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Module info for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }

        try {
            BufferedReader interm = new BufferedReader(new FileReader(termFileName));
            String str;
            int index = 0;
            while ((str = interm.readLine()) != null) {
                nodes.get(index).term = str;
                index++;
            }
            interm.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Term file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }


        // read edges
        String edgeFileName = pathToBackboneInfo + field + Integer.toString(year) + "tree.net";
//        JOptionPane.showMessageDialog(null, edgeFileName);
        try {
            BufferedReader inedge = new BufferedReader(new FileReader(edgeFileName));
            String str;
            boolean edgeLine = false;
            while ((str = inedge.readLine()) != null) {
                if (str.startsWith("*edges")) {
//                    JOptionPane.showMessageDialog(null, "Come here!");
                    edgeLine = true;
                    continue;
                }
                if (edgeLine) {
                    StringTokenizer st = new StringTokenizer(str);

                    Edge e = new Edge();
                    e.source = st.nextToken();
                    e.target = st.nextToken();
                    e.distance = (float)1.0 / Float.valueOf(st.nextToken()) - (float)1.0;
                    edges.add(e);
                }
            }
            inedge.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Edge file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }
        // write xml
        prefuseFName = pathToBackboneInfo + field + Integer.toString(year) + ".xml";
//        JOptionPane.showMessageDialog(null, prefuseFileName);
        try {
            BufferedWriter outPrefuse = new BufferedWriter(new FileWriter(prefuseFName));
            outPrefuse.write("<graphml>");
            outPrefuse.newLine();
            outPrefuse.write("<graph edgedefault=\"directed\">");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"term\" for=\"node\" attr.name=\"term\" attr.type=\"string\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"module\" for=\"node\" attr.name=\"module\" attr.type=\"int\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"distance\" for=\"edge\" attr.name=\"distance\" attr.type=\"float\"/>");
            outPrefuse.newLine();

            for (int in = 0; in < nodes.size(); in++) {
                outPrefuse.write("<node id=\"" + Integer.toString(in + 1) + "\">");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"term\">" + nodes.get(in).term + "</data>");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"module\">" + nodes.get(in).module + "</data>");
                outPrefuse.newLine();
                outPrefuse.write("</node>");
                outPrefuse.newLine();
            }

            for (int ie = 0; ie < edges.size(); ie++) {
                outPrefuse.write("<edge source=\"" + edges.get(ie).source
                        + "\" target=\"" + edges.get(ie).target + "\"><data key=\"distance\">"
                        + Float.toString(edges.get(ie).distance)
                        + "</data> </edge>");
                outPrefuse.newLine();
            }

            outPrefuse.write("</graph>");
            outPrefuse.newLine();
            outPrefuse.write("</graphml>");
            outPrefuse.newLine();
            outPrefuse.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
        }
        return true;
    }

    public boolean writeModifiedXml() {
        // read (term, module)s
        String termFileName = pathToBackboneInfo + field + "." + Integer.toString(year) + ".terms";
        String moduleFileName = pathToNodeInfo + "d." + field + "." + Integer.toString(year) + ".txt";
//        JOptionPane.showMessageDialog(null, termFileName);
//        JOptionPane.showMessageDialog(null, moduleFileName);
        try {
            BufferedReader inmodule = new BufferedReader(new FileReader(moduleFileName));
            String str;

            while ((str = inmodule.readLine()) != null) {
                String[] metrics = str.split(";");
                Node anode = new Node();
                anode.module = Integer.parseInt(metrics[MODULE_INDEX]);
                nodes.add(anode);
            }
            inmodule.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Module info for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }

        try {
            BufferedReader interm = new BufferedReader(new FileReader(termFileName));
            String str;
            int index = 0;
            while ((str = interm.readLine()) != null) {
                nodes.get(index).term = str;
                index++;
            }
            interm.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Term file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }


        // read edges
        String edgeFileName = pathToBackboneInfo + field + Integer.toString(year) + "tree.net";
//        JOptionPane.showMessageDialog(null, edgeFileName);
        try {
            BufferedReader inedge = new BufferedReader(new FileReader(edgeFileName));
            String str;
            boolean edgeLine = false;
            while ((str = inedge.readLine()) != null) {
                if (str.startsWith("*edges")) {
//                    JOptionPane.showMessageDialog(null, "Come here!");
                    edgeLine = true;
                    continue;
                }
                if (edgeLine) {
                    StringTokenizer st = new StringTokenizer(str);

                    Edge e = new Edge();
                    e.source = st.nextToken();
                    e.target = st.nextToken();
                    e.distance = (float)1.0 / Float.valueOf(st.nextToken()) - (float)1.0;
                    edges.add(e);
                }
            }
            inedge.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Edge file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }
        // write xml
        prefuseFName = pathToBackboneInfo + field + Integer.toString(year) + ".xml";
//        JOptionPane.showMessageDialog(null, prefuseFileName);
        try {
            BufferedWriter outPrefuse = new BufferedWriter(new FileWriter(prefuseFName));
            outPrefuse.write("<graphml>");
            outPrefuse.newLine();
            outPrefuse.write("<graph edgedefault=\"directed\">");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"term\" for=\"node\" attr.name=\"term\" attr.type=\"string\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"module\" for=\"node\" attr.name=\"module\" attr.type=\"int\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"distance\" for=\"edge\" attr.name=\"distance\" attr.type=\"float\"/>");
            outPrefuse.newLine();

            for (int in = 0; in < nodes.size(); in++) {
                String idStr = Integer.toString(in + 1);
                boolean test = false;
                for (int itest = 0; itest < edges.size(); itest++) {
                    if (edges.get(itest).source.equals(idStr) || edges.get(itest).target.equals(idStr)) {
                        test = true;
                        break;
                    }
                }

                if (!test) {
                    continue;
                }

                outPrefuse.write("<node id=\"" + Integer.toString(in + 1) + "\">");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"term\">" + nodes.get(in).term + "</data>");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"module\">" + nodes.get(in).module + "</data>");
                outPrefuse.newLine();
                outPrefuse.write("</node>");
                outPrefuse.newLine();
            }

            for (int ie = 0; ie < edges.size(); ie++) {
                outPrefuse.write("<edge source=\"" + edges.get(ie).source
                        + "\" target=\"" + edges.get(ie).target + "\"><data key=\"distance\">"
                        + Float.toString(edges.get(ie).distance)
                        + "</data> </edge>");
                outPrefuse.newLine();
            }

            outPrefuse.write("</graph>");
            outPrefuse.newLine();
            outPrefuse.write("</graphml>");
            outPrefuse.newLine();
            outPrefuse.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
        }
        return true;
    }


    public boolean writeModifiedXmlTargeted(int targetId) {
        // read (term, module)s
        String termFileName = pathToBackboneInfo + field + "." + Integer.toString(year) + ".terms";
        String moduleFileName = pathToNodeInfo + "d." + field + "." + Integer.toString(year) + ".txt";
//        JOptionPane.showMessageDialog(null, termFileName);
//        JOptionPane.showMessageDialog(null, moduleFileName);
        try {
            BufferedReader inmodule = new BufferedReader(new FileReader(moduleFileName));
            String str;

            while ((str = inmodule.readLine()) != null) {
                String[] metrics = str.split(";");
                Node anode = new Node();
                anode.module = Integer.parseInt(metrics[MODULE_INDEX]);
                nodes.add(anode);
            }
            inmodule.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Module info for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }

        try {
            BufferedReader interm = new BufferedReader(new FileReader(termFileName));
            String str;
            int index = 0;
            while ((str = interm.readLine()) != null) {
                nodes.get(index).term = str;
                index++;
            }
            interm.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Term file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }


        // read edges
        String edgeFileName = pathToBackboneInfo + field + Integer.toString(year) + "tree.net";
//        JOptionPane.showMessageDialog(null, edgeFileName);
        try {
            BufferedReader inedge = new BufferedReader(new FileReader(edgeFileName));
            String str;
            boolean edgeLine = false;
            while ((str = inedge.readLine()) != null) {
                if (str.startsWith("*edges")) {
//                    JOptionPane.showMessageDialog(null, "Come here!");
                    edgeLine = true;
                    continue;
                }
                if (edgeLine) {
                    StringTokenizer st = new StringTokenizer(str);

                    Edge e = new Edge();
                    e.source = st.nextToken();
                    e.target = st.nextToken();
                    e.distance = (float)1.0 / Float.valueOf(st.nextToken()) - (float)1.0;

                    if(Integer.valueOf(e.source) == targetId + 1 || Integer.valueOf(e.target) == targetId + 1)
                        edges.add(e);
                }
            }
            inedge.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
            JOptionPane.showMessageDialog(null, "Edge file for year '" + Integer.toString(year) + "' is not available in our database.");
            return false;
        }


        if(edges.size() == 0){
            JOptionPane.showMessageDialog(null, "Graph data for this node is empty.");
            return false;
        }
        // write xml
        prefuseFName = pathToBackboneInfo + field + Integer.toString(year) + "."+ Integer.toString(targetId)+ ".xml";
//        JOptionPane.showMessageDialog(null, prefuseFileName);
        try {
            BufferedWriter outPrefuse = new BufferedWriter(new FileWriter(prefuseFName));
            outPrefuse.write("<graphml>");
            outPrefuse.newLine();
            outPrefuse.write("<graph edgedefault=\"directed\">");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"term\" for=\"node\" attr.name=\"term\" attr.type=\"string\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"module\" for=\"node\" attr.name=\"module\" attr.type=\"int\"/>");
            outPrefuse.newLine();
            outPrefuse.write("<key id=\"distance\" for=\"edge\" attr.name=\"distance\" attr.type=\"float\"/>");
            outPrefuse.newLine();

            for (int in = 0; in < nodes.size(); in++) {
                String idStr = Integer.toString(in + 1);
                boolean test = false;
                for (int itest = 0; itest < edges.size(); itest++) {
                    if (edges.get(itest).source.equals(idStr) || edges.get(itest).target.equals(idStr)) {
                        test = true;
                        break;
                    }
                }

                if (!test) {
                    continue;
                }

                outPrefuse.write("<node id=\"" + Integer.toString(in + 1) + "\">");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"term\">" + nodes.get(in).term + "</data>");
                outPrefuse.newLine();
                outPrefuse.write(" <data key=\"module\">" + nodes.get(in).module + "</data>");
                outPrefuse.newLine();
                outPrefuse.write("</node>");
                outPrefuse.newLine();
            }

            for (int ie = 0; ie < edges.size(); ie++) {
                outPrefuse.write("<edge source=\"" + edges.get(ie).source
                        + "\" target=\"" + edges.get(ie).target + "\"><data key=\"distance\">"
                        + Float.toString(edges.get(ie).distance)
                        + "</data> </edge>");
                outPrefuse.newLine();
            }

            outPrefuse.write("</graph>");
            outPrefuse.newLine();
            outPrefuse.write("</graphml>");
            outPrefuse.newLine();
            outPrefuse.close();
        } catch (IOException ex) {
            System.out.println(ex.toString());
        }
        return true;
    }
}

