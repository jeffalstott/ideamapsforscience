/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ideamapsdiscoverer;

import prefuse.action.layout.graph.ForceDirectedLayout;
import prefuse.visual.EdgeItem; 

public class WeightedForceDirectedLayout extends ForceDirectedLayout {

    public WeightedForceDirectedLayout(String graph) {
        super(graph);
    }

//    @Override
    protected float getSpringLength(EdgeItem e) {
        if (e.canGetFloat("distance")) {
            return e.getFloat("distance");
        } else {
            return super.getSpringLength(e);
        }
    }
}