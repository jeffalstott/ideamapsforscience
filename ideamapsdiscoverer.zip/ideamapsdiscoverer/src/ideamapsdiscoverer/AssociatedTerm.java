/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ideamapsdiscoverer;

/**
 *
 * @author Diep
 */
public class AssociatedTerm implements java.util.Comparator {
    public String content;
    public double strength;
	public int compare(Object t1, Object t2){
        AssociatedTerm at1 = (AssociatedTerm) t1;
        AssociatedTerm at2 = (AssociatedTerm) t2;
        if(at1.strength > at2.strength) return -1;
        if(at1.strength < at2.strength) return 1;
		if(at1.strength == at2.strength){
            if(at1.content.compareTo(at2.content) < 0) return -1;
            else if(at1.content.compareTo(at2.content) > 0) return 1;        
        }
        return 0;		
	}	
}
